#### 1.Mybatis动态Sql是做什么的？都有哪些动态Sql?简述一下Sql的执行原理？

答:  (1). Mybatis 动态 SQL ，可以让我们在 XML 映射文件内，以 XML 标签的形 式编写动态 SQL ，完成逻辑判断和动态拼接 SQL 的功能。

​		  (2). Mybatis动态sql有<if/>、<choose/>、<when/>、

<otherwise/>、<trim/>、<when/>、<set/>、<foreach/>、<bind/>             

​         (3). 其执行原理为，使用 OGNL 的表达式，从 SQL 参数对象中计算表达式的值,根据表达式的值动态拼接 SQL ，以此来完成动态 SQL 的功能。



#### 2.Mybatis是否支持延迟加载？如果支持，它的实现原理是什么？

答:  只支持一对一和一对多的延迟加载。原理：使用CGLIB创建目标对戏那个的代理对象，当调用目标方法时，进入拦截器方法。



#### 3.Mybatis有哪些执行器？它们之间的区别是什么？

答：SimpleExecutor：每次执行update或select操作开启一个Statement对象，用完立刻就关闭

ReuseExecutor：执行update或select操作时，以sql作为key查找statement对象，存在就获取对象使用，没有就创建，不关闭statement对象，而是放在map内，供下一次使用。

BatchExecutor：执行update没有select,将sql添加到批处理中，等待统一执行，缓存了多个statement对象。

​	



#### 4.简述下Mybatis的一级，二级缓存（分别从存储结构，范围，失效场景三个方面来作答？

答：一级缓存：存储结构为HashMap的方式存储；范围是同一个sqlSession；失效场景：(1).中间sqlSession执行了commit操作就会清空一级缓存,   (2).每一次sql使用新的sqlSession。

​		二级缓存：二级缓存可以存储在内存中也可以存在硬盘中；范围是跨sqlSession的；失效场景：每个增删改查操作的 flush="true"二级缓存都会被清空。



#### 5.简述Mybatis的插件运行原理，以及如何编写一个插件？

答：1.每个创建出来的对象不是直接返回的，而是interceptorChain.pluginAll(paramterHandler);

​		2.获取到所有的Interceptor，调用interceptor.plugin(target);返回target包装的对象

​		3.插件机制，可以使用插件为目标对象创建一个代理对象

​	步骤：

​		(1). 编写Interceptor接口的实现类

​		(2).设置插件的签名，告诉mybatis拦截哪个对象的哪个方法

​		(3).最后将插件注册到全局配置文件中



